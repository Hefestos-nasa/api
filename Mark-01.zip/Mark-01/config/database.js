// Sets the MongoDB Database options

module.exports = {

    mongolab:
    {
        name: "mongolab",
        url: "mongodb://admin:admin@ds123351.mlab.com:23351/hackathon-nasa",
        port: 27017
    }
}
